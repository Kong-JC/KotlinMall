package com.module.user.domain;

public class ConfirmOrderReq {
    private Integer orderId;

    public Integer getOrderId() {
        return this.orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }
}
