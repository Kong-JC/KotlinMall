/*    */ package com.module.user.model;
/*    */ 
/*    */ public class OrderInfo
/*    */ {
/*    */   private Integer id;
/*    */   private Integer userId;
/*    */   private Integer payType;
/*    */   private Integer shipId;
/*    */   private String totalPrice;
/*    */   private Integer orderStatus;
/*    */ 
/*    */   public Integer getId()
/*    */   {
/* 17 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(Integer id) {
/* 21 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public Integer getUserId() {
/* 25 */     return this.userId;
/*    */   }
/*    */ 
/*    */   public void setUserId(Integer userId) {
/* 29 */     this.userId = userId;
/*    */   }
/*    */ 
/*    */   public Integer getPayType() {
/* 33 */     return this.payType;
/*    */   }
/*    */ 
/*    */   public void setPayType(Integer payType) {
/* 37 */     this.payType = payType;
/*    */   }
/*    */ 
/*    */   public Integer getShipId() {
/* 41 */     return this.shipId;
/*    */   }
/*    */ 
/*    */   public void setShipId(Integer shipId) {
/* 45 */     this.shipId = shipId;
/*    */   }
/*    */ 
/*    */   public String getTotalPrice() {
/* 49 */     return this.totalPrice;
/*    */   }
/*    */ 
/*    */   public void setTotalPrice(String totalPrice) {
/* 53 */     this.totalPrice = totalPrice;
/*    */   }
/*    */ 
/*    */   public Integer getOrderStatus() {
/* 57 */     return this.orderStatus;
/*    */   }
/*    */ 
/*    */   public void setOrderStatus(Integer orderStatus) {
/* 61 */     this.orderStatus = orderStatus;
/*    */   }
/*    */ }

/* Location:           E:\WorkSpace\App\Test\appidzbnbo3hx6t\ROOT\WEB-INF\classes\
 * Qualified Name:     com.module.user.model.OrderInfo
 * JD-Core Version:    0.6.2
 */