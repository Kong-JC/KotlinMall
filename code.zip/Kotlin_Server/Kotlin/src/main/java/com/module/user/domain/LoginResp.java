package com.module.user.domain;

public class LoginResp extends BaseResp {
}
