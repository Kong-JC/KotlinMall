package com.module.user.domain;

public class GetOrderListReq {
    private Integer orderStatus;

    public Integer getOrderStatus() {
        return this.orderStatus;
    }

    public void setOrderStatus(Integer orderStatus) {
        this.orderStatus = orderStatus;
    }
}
