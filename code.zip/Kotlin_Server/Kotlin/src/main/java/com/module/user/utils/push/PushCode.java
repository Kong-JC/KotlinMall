package com.module.user.utils.push;

public class PushCode
{
  public static final int CODE_LOGIN = 1;
  public static final int CODE_SUBMIT_ORDER = 2;
}