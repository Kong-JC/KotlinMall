package com.module.user.domain;

public class ModifyPwdResp extends BaseResp {
}

