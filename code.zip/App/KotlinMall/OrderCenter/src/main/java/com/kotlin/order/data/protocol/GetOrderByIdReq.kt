package com.kotlin.order.data.protocol

/*
    根据ID查询订单
 */
data class GetOrderByIdReq(val orderId: Int)
