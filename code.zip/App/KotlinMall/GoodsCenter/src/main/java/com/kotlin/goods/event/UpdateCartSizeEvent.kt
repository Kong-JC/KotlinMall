package com.kotlin.goods.event

/*
    更新购物车数量事件
 */
class UpdateCartSizeEvent
