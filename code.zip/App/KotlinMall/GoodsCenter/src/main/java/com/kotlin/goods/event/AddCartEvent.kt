package com.kotlin.goods.event

/*
    加入购物车事件
 */
class AddCartEvent
