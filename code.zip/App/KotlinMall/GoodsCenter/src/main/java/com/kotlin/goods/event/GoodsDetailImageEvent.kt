package com.kotlin.goods.event

/*
    商品详情Tab two 事件
 */
class GoodsDetailImageEvent(val imgOne:String,val imgTwo:String)
