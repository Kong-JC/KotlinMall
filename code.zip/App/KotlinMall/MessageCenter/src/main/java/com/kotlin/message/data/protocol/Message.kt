package com.kotlin.message.data.protocol

/*
    消息实体
 */
data class Message(val msgIcon:String,val msgTitle:String,val msgContent:String,val msgTime:String)
